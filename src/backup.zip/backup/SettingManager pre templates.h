#ifndef SETTINGMANAGER_H
#define SETTINGMANAGER_H

#include <Arduino.h>
#include <vector>

#include <ArduinoNvs.h>

class SettingManager {
  public:
    SettingManager(String nvs_namespace = "storage");

    void addSetting(String key, int* var, int default_value = -1);
    void addSetting(String key, float* var, float default_value = -1.0);
    void addSetting(String key, String* var, String default_value = "");

    bool loadSavedSettings();
    void loadDefaultSettings();
    bool saveSettings();

  private:
    enum class SettingType {
      INTEGER,
      FLOAT,
      STRING
    };

    struct Setting {
      String key;
      union {
        int* var_int;
        float* var_float;
        String* var_string;
      } var;
      union {
        int default_int;
        float default_float;
        String default_string;
      } default_value;
      SettingType type;

      Setting(String key, int* var, int default_value);
      Setting(String key, float* var, float default_value);
      Setting(String key, String* var, String default_value);
    };

    std::vector<Setting> settings;
};

#endif /* SETTINGMANAGER_H */
