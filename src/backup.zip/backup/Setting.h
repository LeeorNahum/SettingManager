#ifndef SETTING_H
#define SETTING_H

#include <Arduino.h>

class SettingBase {
  public:
  virtual ~SettingBase() {}

  virtual void loadSavedSetting() = 0;
  virtual void loadDefaultSetting() = 0;
  virtual void saveSetting() = 0;
};

template<typename Type = int>
class Setting : public SettingBase {
  public:
  friend class SettingManager;

  void loadSavedSetting() override;
  void loadDefaultSetting() override;
  void saveSetting() override;

  private:
  Setting(String key, Type* var, Type default_value = Type());

  String key;
  Type* var;
  Type default_value;
};

#include "Setting.tpp"

#endif /* SETTING_H */
