#ifndef SETTINGMANAGER_H
#define SETTINGMANAGER_H

#include <Arduino.h>
#include <vector>
#include <ArduinoNvs.h>

#include "Setting.h"

class SettingManager {
  public:
  SettingManager(String nvs_namespace);
  SettingManager();
  ~SettingManager();

  template<typename Type>
  void addSetting(String key, Type* var, Type default_value = Type());

  void loadSavedSettings();
  void loadDefaultSettings();
  bool saveSettings();

  private:
  std::vector<SettingBase*> settings;
};

#include "SettingManager.cpp"

#endif /* SETTINGMANAGER_H */
