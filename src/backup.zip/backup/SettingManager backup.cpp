#include "SettingManager.h"

SettingManager::SettingManager(String nvs_key_name, const char* default_settings_json) :
  nvs_key_name(nvs_key_name),
  default_settings_json(default_settings_json)
{
}

void SettingManager::addSetting(const char* path, bool* var) {
  this->settings.push_back(Setting(path, var));
}

void SettingManager::addSetting(const char* path, int* var) {
  this->settings.push_back(Setting(path, var));
}

void SettingManager::addSetting(const char* path, float* var) {
  this->settings.push_back(Setting(path, var));
}

void SettingManager::addSetting(const char* path, String* var) {
  this->settings.push_back(Setting(path, var));
}

bool SettingManager::loadSavedSettings() {
  if (this->getDocFromNvs(this->json_doc_buffer)) {
    this->applySettingsFromDoc(this->json_doc_buffer);
    return true;
  }
  return this->saveSettings();
}

bool SettingManager::loadDefaultSettings() {
  deserializeJson(this->json_doc_buffer, this->default_settings_json);
  this->applySettingsFromDoc(this->json_doc_buffer);
  return true;
}

bool SettingManager::saveSettings() {
  this->fillDocWithSettings(this->json_doc_buffer);
  return this->saveDocToNvs(this->json_doc_buffer);
}

SettingManager::Setting::Setting(const char* path, bool* var) :
  path(path),
  type(SettingType::BOOLEAN)
{
  this->var.var_bool = var;
}

SettingManager::Setting::Setting(const char* path, int* var) :
  path(path),
  type(SettingType::INTEGER)
{
  this->var.var_int = var;
}

SettingManager::Setting::Setting(const char* path, float* var) :
  path(path),
  type(SettingType::FLOAT)
{
  this->var.var_float = var;
}

SettingManager::Setting::Setting(const char* path, String* var) :
  path(path),
  type(SettingType::STRING)
{
  this->var.var_string = var;
}

bool SettingManager::getDocFromNvs(StaticJsonDocument<JSON_SETTINGS_DOC_SIZE>& doc) {
  size_t blob_length = NVS.getBlobSize(this->nvs_key_name);
  if (blob_length == 0) return false;

  std::vector<uint8_t> blob(blob_length);
  if (!NVS.getBlob(this->nvs_key_name, blob)) return false;

  DeserializationError json_err = deserializeJson(doc, blob.data(), blob.size());
  return !json_err;
}

void SettingManager::applySettingsFromDoc(StaticJsonDocument<JSON_SETTINGS_DOC_SIZE>& doc) {
  for (Setting& setting : this->settings) {
    JsonVariant variant = resolvePath(doc, setting.path);
    switch (setting.type) {
      case SettingType::BOOLEAN:
        *(setting.var.var_bool) = variant.as<bool>();
        break;
      case SettingType::INTEGER:
        *(setting.var.var_int) = variant.as<int>();
        break;
      case SettingType::FLOAT:
        *(setting.var.var_float) = variant.as<float>();
        break;
      case SettingType::STRING:
        *(setting.var.var_string) = variant.as<String>();
        break;
    }
  }
}

void SettingManager::fillDocWithSettings(StaticJsonDocument<JSON_SETTINGS_DOC_SIZE>& doc) {
  for (Setting& setting : this->settings) {
    JsonVariant variant = resolvePath(doc, setting.path);
    switch (setting.type) {
      case SettingType::BOOLEAN:
        variant.set(*(setting.var.var_bool));
        break;
      case SettingType::INTEGER:
        variant.set(*(setting.var.var_int));
        break;
      case SettingType::FLOAT:
        variant.set(*(setting.var.var_float));
        break;
      case SettingType::STRING:
        variant.set(*(setting.var.var_string));
        break;
    }
  }
}

bool SettingManager::saveDocToNvs(StaticJsonDocument<JSON_SETTINGS_DOC_SIZE>& doc) {
  std::vector<uint8_t> blob(JSON_SETTINGS_DOC_SIZE);
  size_t actual_size = serializeJson(doc, blob.data(), JSON_SETTINGS_DOC_SIZE);
  blob.resize(actual_size);

  return NVS.setBlob(this->nvs_key_name, blob);
}

JsonVariant SettingManager::resolvePath(JsonDocument& doc, const String& path) {
  size_t index = 0;
  JsonVariant variant = doc.as<JsonVariant>();
  while (index < path.length()) {
    int end = path.indexOf('.', index);
    if (end == -1) {
      end = path.length();
    }
    String token = path.substring(index, end);
    variant = variant[token];
    index = end + 1;
  }
  return variant;
}
