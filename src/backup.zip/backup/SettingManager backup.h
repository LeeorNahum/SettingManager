#ifndef SETTINGMANAGER_H
#define SETTINGMANAGER_H

#include <ArduinoJson.h>
#include <ArduinoNvs.h>

// Maximum size for the JSON document
#define JSON_SETTINGS_DOC_SIZE 768

class SettingManager {
  public:
    SettingManager(String nvs_key_name, const char* default_settings_json);

    void addSetting(const char* path, bool* var);
    void addSetting(const char* path, int* var);
    void addSetting(const char* path, float* var);
    void addSetting(const char* path, String* var);

    bool loadSavedSettings();
    bool loadDefaultSettings();
    bool saveSettings();

  private:
    enum class SettingType {
      BOOLEAN,
      INTEGER,
      FLOAT,
      STRING
    };

    struct Setting {
      String path;
      union {
        bool* var_bool;
        int* var_int;
        float* var_float;
        String* var_string;
      } var;
      SettingType type;

      Setting(const char* path, bool* var);
      Setting(const char* path, int* var);
      Setting(const char* path, float* var);
      Setting(const char* path, String* var);
    };

    String nvs_key_name;
    const char* default_settings_json;
    std::vector<Setting> settings;
    StaticJsonDocument<JSON_SETTINGS_DOC_SIZE> json_doc_buffer;

    bool getDocFromNvs(StaticJsonDocument<JSON_SETTINGS_DOC_SIZE>& doc);
    void applySettingsFromDoc(StaticJsonDocument<JSON_SETTINGS_DOC_SIZE>& doc);
    void fillDocWithSettings(StaticJsonDocument<JSON_SETTINGS_DOC_SIZE>& doc);
    bool saveDocToNvs(StaticJsonDocument<JSON_SETTINGS_DOC_SIZE>& doc);
    JsonVariant resolvePath(JsonDocument& doc, const String& path);
};

#endif /* SETTINGMANAGER_H */
