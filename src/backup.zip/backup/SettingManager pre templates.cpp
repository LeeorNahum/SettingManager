#include "SettingManager.h"

SettingManager::SettingManager(String nvs_namespace) {
  NVS.begin(nvs_namespace);
}

void SettingManager::addSetting(String key, int* var, int default_value) {
  if (default_value == -1) default_value = *var;
  this->settings.push_back(Setting(key, var, default_value));
}

void SettingManager::addSetting(String key, float* var, float default_value) {
  if (default_value == -1.0) default_value = *var;
  this->settings.push_back(Setting(key, var, default_value));
}

void SettingManager::addSetting(String key, String* var, String default_value) {
  if (default_value == "") default_value = *var;
  this->settings.push_back(Setting(key, var, default_value));
}

bool SettingManager::loadSavedSettings() {
  for (Setting& setting : this->settings) {
    switch (setting.type) {
      case SettingType::INTEGER:
        *(setting.var.var_int) = NVS.getInt(setting.key, *(setting.var.var_int));
        break;
      case SettingType::FLOAT:
        *(setting.var.var_float) = NVS.getFloat(setting.key, *(setting.var.var_float));
        break;
      case SettingType::STRING:
        *(setting.var.var_string) = NVS.getString(setting.key, *(setting.var.var_string));
        break;
    }
  }
  return true;
}

void SettingManager::loadDefaultSettings() {
  for (Setting& setting : this->settings) {
    switch (setting.type) {
      case SettingType::INTEGER:
        *(setting.var.var_int) = setting.default_value.default_int;
        break;
      case SettingType::FLOAT:
        *(setting.var.var_float) = setting.default_value.default_float;
        break;
      case SettingType::STRING:
        *(setting.var.var_string) = setting.default_value.default_string;
        break;
    }
  }
}

bool SettingManager::saveSettings() {
  for (Setting& setting : this->settings) {
    switch (setting.type) {
      case SettingType::INTEGER:
        NVS.setInt(setting.key, *(setting.var.var_int));
        break;
      case SettingType::FLOAT:
        NVS.setFloat(setting.key, *(setting.var.var_float));
        break;
      case SettingType::STRING:
        NVS.setString(setting.key, *(setting.var.var_string));
        break;
    }
  }
  return NVS.commit();
}

SettingManager::Setting::Setting(String key, int* var, int default_value) :
  key(key),
  type(SettingType::INTEGER)
{
  this->var.var_int = var;
  this->default_value.default_int = default_value;
}

SettingManager::Setting::Setting(String key, float* var, float default_value) :
  key(key),
  type(SettingType::FLOAT)
{
  this->var.var_float = var;
  this->default_value.default_float = default_value;
}

SettingManager::Setting::Setting(String key, String* var, String default_value) :
  key(key),
  type(SettingType::STRING)
{
  this->var.var_string = var;
  this->default_value.default_string = default_value;
}
