#include "SettingManager.h"

SettingManager::SettingManager(String nvs_namespace) {
  NVS.begin(nvs_namespace);
}

SettingManager::SettingManager() {}

SettingManager::~SettingManager() {
  for (SettingBase* setting : this->settings) {
    delete setting;
  }
}

template<typename Type>
void SettingManager::addSetting(String key, Type* var, Type default_value) {
  Setting<Type>* new_setting = new Setting<Type>(key, var, default_value);
  this->settings.push_back(new_setting);
}

void SettingManager::loadSavedSettings() {
  for (SettingBase* setting : this->settings) {
    setting->loadSavedSetting();
  }
}

void SettingManager::loadDefaultSettings() {
  for (SettingBase* setting : this->settings) {
    setting->loadDefaultSetting();
  }
}

bool SettingManager::saveSettings() {
  for (SettingBase* setting : this->settings) {
    setting->saveSetting();
  }
  return NVS.commit();
}

#include "Setting.tpp"
